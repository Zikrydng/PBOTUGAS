import greenfoot.*;  // Import Greenfoot classes

public class ChasingEnemy extends Actor {
    private int speed = 2;  // Kecepatan musuh (sesuaikan sesuai keinginan)

    public void act() {
        chasePlayer();
    }

    public void chasePlayer() {
        Player player = (Player) getWorld().getObjects(Player.class).get(0);

        if (player != null) {
            int playerX = player.getX();
            int playerY = player.getY();
            int enemyX = getX();
            int enemyY = getY();
            int dx = playerX - enemyX;
            int dy = playerY - enemyY;
            
            // Hitung sudut arah
            int angle = (int) Math.toDegrees(Math.atan2(dy, dx));
            
            // Hitung pergerakan berdasarkan kecepatan
            int deltaX = (int)(Math.cos(Math.toRadians(angle)) * speed);
            int deltaY = (int)(Math.sin(Math.toRadians(angle)) * speed);
            
            // Pindahkan musuh ke arah pemain dengan kecepatan yang ditentukan
            setLocation(getX() + deltaX, getY() + deltaY);
            
            // Periksa tabrakan dengan pemain
            if (isTouching(Player.class)) {
                Greenfoot.stop();  // Hentikan permainan
                GreenfootImage gameOverImage = new GreenfootImage("Game Over", 48, Color.RED, Color.BLACK);
                getWorld().getBackground().drawImage(gameOverImage, 200, 200);
            }
        }
    }
}
