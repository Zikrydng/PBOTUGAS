import greenfoot.*;  // Import Greenfoot classes

public class Food extends Actor {
    public void act() {
        checkCollision();
    }

    public void checkCollision() {
        Player player = (Player) getOneIntersectingObject(Player.class);
        if (player != null) {
            MyWorld world = (MyWorld) getWorld();
            world.decrementFoodCount();  // Kurangi jumlah makanan yang tersisa
            getWorld().removeObject(this);  // Hapus makanan
        }
    }
}
