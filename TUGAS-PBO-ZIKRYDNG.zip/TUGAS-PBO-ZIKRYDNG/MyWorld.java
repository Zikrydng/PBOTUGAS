import greenfoot.*;  // Import Greenfoot classes

public class MyWorld extends World {
    private int foodCount = 10;  // Jumlah makanan yang diperlukan untuk menang

    public MyWorld() {
        super(600, 400, 1);
        addObject(new Player(), getWidth() / 2, getHeight() / 2);
        
        // Tambahkan makanan ke dunia
        for (int i = 0; i < foodCount; i++) {
            addObject(new Food(), Greenfoot.getRandomNumber(getWidth()), Greenfoot.getRandomNumber(getHeight()));
        }
    }

    public void act() {
        checkGameOver();
    }

    public void checkGameOver() {
        // Periksa apakah pemain menang
        if (foodCount == 0) {
            GreenfootImage winImage = new GreenfootImage("Winner", 48, Color.GREEN, Color.BLACK);
            getBackground().drawImage(winImage, 200, 200);
            Greenfoot.stop();  // Hentikan permainan
        }
    }

    public void decrementFoodCount() {
        foodCount--;
    }
}
