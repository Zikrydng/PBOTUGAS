import greenfoot.*;  // Import Greenfoot classes

public class Player extends Actor {
    private int speed = 4;  // Kecepatan pemain

    public void act() {
        checkKeyPress();
    }

    public void checkKeyPress() {
        if (Greenfoot.isKeyDown("up")) {
            setLocation(getX(), getY() - speed);
        }
        if (Greenfoot.isKeyDown("down")) {
            setLocation(getX(), getY() + speed);
        }
        if (Greenfoot.isKeyDown("left")) {
            setLocation(getX() - speed, getY());
        }
        if (Greenfoot.isKeyDown("right")) {
            setLocation(getX() + speed, getY());
        }
    }
}
